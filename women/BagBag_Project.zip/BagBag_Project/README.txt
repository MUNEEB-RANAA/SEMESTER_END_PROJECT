BagBag - Online Bag Store

How to run:
1. Extract the zip file.
2. Open index.html in any modern browser.
3. Keep the css, js and assets folders in the same directory as index.html.

Included:
- index.html
- css/style.css
- js/script.js
- assets/images/bagbag-logo.png
- assets/videos/hero-bagbag.mp4
- assets/docs/BagBag-Product-Catalog.pdf
- assets/docs/BagBag-Product-Catalog.doc

Built with only HTML5, CSS3, Bootstrap 5, JavaScript and jQuery.
