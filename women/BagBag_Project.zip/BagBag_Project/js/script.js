/* =====================================================
   BagBag - Frontend Interactions
   jQuery used for rendering, filtering, validation,
   animations, lightbox, smooth scroll and cart UI.
===================================================== */

$(function () {
  "use strict";

  const fallbackImage = "assets/images/fallback-bag.svg";
  let cartCount = 0;
  let selectedProductId = null;

  // Product data keeps the HTML clean and makes filtering easier.
  const products = [
    {
      id: 1,
      gender: "men",
      category: "laptop",
      name: "Executive Laptop Backpack",
      brand: "American Tourister",
      price: "PKR 11,999",
      discount: "20% OFF",
      image: "https://source.unsplash.com/900x1050/?black,laptop,backpack&sig=501",
      description: "A clean, business-ready backpack with padded laptop storage and everyday organization.",
      specs: { Material: "Ballistic Nylon", Capacity: "28L", Color: "Matte Black", Waterproof: "Yes" }
    },
    {
      id: 2,
      gender: "men",
      category: "sling",
      name: "Urban Crossbody Sling",
      brand: "Puma",
      price: "PKR 5,499",
      discount: "15% OFF",
      image: "https://source.unsplash.com/900x1050/?men,sling,bag&sig=502",
      description: "Compact crossbody sling made for phones, wallet, keys and daily essentials.",
      specs: { Material: "Polyester", Capacity: "7L", Color: "Charcoal", Waterproof: "Water Resistant" }
    },
    {
      id: 3,
      gender: "men",
      category: "travel",
      name: "Trek Travel Duffel",
      brand: "Safari",
      price: "PKR 14,500",
      discount: "25% OFF",
      image: "https://source.unsplash.com/900x1050/?duffel,travel,bag&sig=503",
      description: "Spacious duffel bag for weekend trips, gym use and short travel plans.",
      specs: { Material: "Canvas Blend", Capacity: "45L", Color: "Olive Green", Waterproof: "No" }
    },
    {
      id: 4,
      gender: "men",
      category: "bags",
      name: "Metro Office Briefcase",
      brand: "VIP",
      price: "PKR 9,999",
      discount: "10% OFF",
      image: "https://source.unsplash.com/900x1050/?leather,briefcase,bag&sig=504",
      description: "Professional office briefcase with structured compartments and premium finish.",
      specs: { Material: "Vegan Leather", Capacity: "18L", Color: "Brown", Waterproof: "No" }
    },
    {
      id: 5,
      gender: "men",
      category: "backpack",
      name: "Trail Pro Backpack",
      brand: "Wildcraft",
      price: "PKR 8,750",
      discount: "18% OFF",
      image: "https://source.unsplash.com/900x1050/?outdoor,backpack,bag&sig=505",
      description: "Durable backpack with comfortable straps and multiple sections for outdoor use.",
      specs: { Material: "Ripstop Fabric", Capacity: "32L", Color: "Forest Green", Waterproof: "Yes" }
    },
    {
      id: 6,
      gender: "men",
      category: "bags",
      name: "Active Sports Holdall",
      brand: "Adidas",
      price: "PKR 7,899",
      discount: "12% OFF",
      image: "https://source.unsplash.com/900x1050/?gym,sports,bag&sig=506",
      description: "Lightweight sports bag for gym sessions, football practice and quick travel.",
      specs: { Material: "Polyester", Capacity: "35L", Color: "Navy Blue", Waterproof: "Water Resistant" }
    },
    {
      id: 7,
      gender: "women",
      category: "bags",
      name: "Luxe Signature Handbag",
      brand: "BagBag",
      price: "PKR 12,999",
      discount: "22% OFF",
      image: "https://source.unsplash.com/900x1050/?luxury,handbag,women&sig=507",
      description: "Elegant handbag with a polished shape, soft handle and premium daily styling.",
      specs: { Material: "Premium PU", Capacity: "14L", Color: "Caramel", Waterproof: "No" }
    },
    {
      id: 8,
      gender: "women",
      category: "sling",
      name: "Rose Gold Sling Bag",
      brand: "Skybags",
      price: "PKR 6,250",
      discount: "16% OFF",
      image: "https://source.unsplash.com/900x1050/?women,sling,bag,purse&sig=508",
      description: "A compact sling with a polished strap and evening-ready silhouette.",
      specs: { Material: "Faux Leather", Capacity: "6L", Color: "Rose Gold", Waterproof: "No" }
    },
    {
      id: 9,
      gender: "women",
      category: "bags",
      name: "Velvet Office Tote",
      brand: "VIP",
      price: "PKR 10,850",
      discount: "19% OFF",
      image: "https://source.unsplash.com/900x1050/?office,tote,bag,women&sig=509",
      description: "A polished tote for office days, documents, makeup pouch and daily essentials.",
      specs: { Material: "Textured Leather", Capacity: "22L", Color: "Cream Beige", Waterproof: "No" }
    },
    {
      id: 10,
      gender: "women",
      category: "travel",
      name: "Weekend Travel Satchel",
      brand: "Safari",
      price: "PKR 13,750",
      discount: "24% OFF",
      image: "https://source.unsplash.com/900x1050/?weekend,travel,bag,women&sig=510",
      description: "A soft travel satchel with enough space for clothing, cosmetics and accessories.",
      specs: { Material: "Canvas Leather", Capacity: "38L", Color: "Tan", Waterproof: "Water Resistant" }
    },
    {
      id: 11,
      gender: "women",
      category: "laptop",
      name: "Pearl Laptop Tote",
      brand: "American Tourister",
      price: "PKR 11,200",
      discount: "14% OFF",
      image: "https://source.unsplash.com/900x1050/?laptop,tote,bag,women&sig=511",
      description: "A work tote with padded laptop space and a refined look for meetings.",
      specs: { Material: "Nylon Leather", Capacity: "24L", Color: "Black Pearl", Waterproof: "Yes" }
    },
    {
      id: 12,
      gender: "women",
      category: "backpack",
      name: "Mini City Backpack",
      brand: "Wildcraft",
      price: "PKR 7,350",
      discount: "17% OFF",
      image: "https://source.unsplash.com/900x1050/?mini,backpack,women&sig=512",
      description: "Small backpack for casual outings, college essentials and city walks.",
      specs: { Material: "Soft Polyester", Capacity: "16L", Color: "Dusty Pink", Waterproof: "Water Resistant" }
    }
  ];

  const galleryImages = [
    "https://source.unsplash.com/900x1100/?luxury,handbag&sig=601",
    "https://source.unsplash.com/900x1100/?black,backpack&sig=602",
    "https://source.unsplash.com/900x1100/?travel,luggage,bag&sig=603",
    "https://source.unsplash.com/900x1100/?leather,briefcase&sig=604",
    "https://source.unsplash.com/900x1100/?women,purse&sig=605",
    "https://source.unsplash.com/900x1100/?gym,bag&sig=606",
    "https://source.unsplash.com/900x1100/?fashion,bag&sig=607",
    "https://source.unsplash.com/900x1100/?laptop,bag&sig=608",
    "https://source.unsplash.com/900x1100/?duffel,bag&sig=609",
    "https://source.unsplash.com/900x1100/?sling,bag&sig=610",
    "https://source.unsplash.com/900x1100/?boutique,handbag&sig=611",
    "https://source.unsplash.com/900x1100/?college,backpack&sig=612"
  ];

  // Render product cards.
  function renderProducts() {
    const menCards = products.filter(product => product.gender === "men").map(productCardTemplate).join("");
    const womenCards = products.filter(product => product.gender === "women").map(productCardTemplate).join("");

    $("#menProducts").html(menCards);
    $("#womenProducts").html(womenCards);
  }

  function productCardTemplate(product) {
    return `
      <div class="col-md-6 col-xl-4 product-card-wrapper" data-category="${product.category}" data-product-id="${product.id}">
        <article class="product-card">
          <div class="product-image-wrap">
            <img src="${product.image}" onerror="this.src='${fallbackImage}'" alt="${product.name}" loading="lazy">
            <span class="discount-badge">${product.discount}</span>
          </div>
          <div class="product-content">
            <p class="product-brand">${product.brand}</p>
            <h3>${product.name}</h3>
            <ul class="spec-list">
              <li><span>Material</span><span>${product.specs.Material}</span></li>
              <li><span>Capacity</span><span>${product.specs.Capacity}</span></li>
              <li><span>Color</span><span>${product.specs.Color}</span></li>
              <li><span>Waterproof</span><span>${product.specs.Waterproof}</span></li>
            </ul>
            <div class="price-row">
              <span class="price">${product.price}</span>
            </div>
            <div class="product-actions">
              <button class="btn btn-dark add-cart" type="button" data-product-id="${product.id}"><i class="fa-solid fa-cart-plus"></i> Add</button>
              <button class="btn btn-outline-dark view-details" type="button" data-product-id="${product.id}"><i class="fa-solid fa-eye"></i> Details</button>
            </div>
          </div>
        </article>
      </div>`;
  }

  // Render gallery items.
  function renderGallery() {
    const galleryMarkup = galleryImages.map((image, index) => `
      <div class="gallery-item" data-image="${image}">
        <img src="${image}" onerror="this.src='${fallbackImage}'" alt="BagBag gallery image ${index + 1}" loading="lazy">
      </div>
    `).join("");

    $("#galleryGrid").html(galleryMarkup);
  }

  renderProducts();
  renderGallery();
  $("#year").text(new Date().getFullYear());

  // Product filtering without page reload.
  function applyFilter(filterValue) {
    $(".filter-btn").removeClass("active");
    $(`.filter-btn[data-filter='${filterValue}']`).addClass("active");

    if (filterValue === "all") {
      $(".product-card-wrapper").stop(true, true).fadeIn(250);
      return;
    }

    $(".product-card-wrapper").each(function () {
      const productCategory = $(this).data("category");
      if (productCategory === filterValue) {
        $(this).stop(true, true).fadeIn(250);
      } else {
        $(this).stop(true, true).fadeOut(160);
      }
    });
  }

  $(document).on("click", ".filter-btn", function () {
    applyFilter($(this).data("filter"));
  });

  $(document).on("click", ".filter-shortcut", function () {
    const filterValue = $(this).data("filter");
    applyFilter(filterValue);
    scrollToSection("#products");
  });

  // Product detail modal.
  $(document).on("click", ".view-details", function () {
    const productId = Number($(this).data("product-id"));
    const product = products.find(item => item.id === productId);
    if (!product) return;

    selectedProductId = productId;
    $("#modalProductImage").attr("src", product.image).attr("alt", product.name);
    $("#modalProductBrand").text(product.brand);
    $("#productModalLabel").text(product.name);
    $("#modalProductDescription").text(product.description);
    $("#modalProductPrice").text(product.price);
    $("#modalProductDiscount").text(product.discount);

    const specsMarkup = Object.entries(product.specs)
      .map(([key, value]) => `<li><strong>${key}</strong><span>${value}</span></li>`)
      .join("");
    $("#modalProductSpecs").html(specsMarkup);

    const modal = new bootstrap.Modal(document.getElementById("productModal"));
    modal.show();
  });

  // Add to cart UI.
  $(document).on("click", ".add-cart, .add-modal-cart", function () {
    cartCount += 1;
    $("#cartCount").text(cartCount);

    const toastElement = document.getElementById("cartToast");
    const toast = bootstrap.Toast.getOrCreateInstance(toastElement, { delay: 1800 });
    toast.show();
  });

  // Gallery lightbox popup.
  $(document).on("click", ".gallery-item", function () {
    const image = $(this).data("image");
    $("#lightboxImage").attr("src", image).attr("alt", "BagBag gallery preview");
    const modal = new bootstrap.Modal(document.getElementById("galleryModal"));
    modal.show();
  });

  $("#modalProductImage, #lightboxImage").on("error", function () {
    $(this).attr("src", fallbackImage);
  });

  // Smooth scrolling for internal links.
  $(document).on("click", "a[href^='#']", function (event) {
    const target = $(this).attr("href");
    if (!target || target === "#" || !$(target).length) return;

    event.preventDefault();
    scrollToSection(target);

    const navbarCollapse = $("#navbarNav");
    if (navbarCollapse.hasClass("show")) {
      bootstrap.Collapse.getOrCreateInstance(navbarCollapse[0]).hide();
    }
  });

  function scrollToSection(target) {
    const headerHeight = $(".site-header").outerHeight() || 0;
    const top = $(target).offset().top - headerHeight + 2;
    $("html, body").animate({ scrollTop: top }, 650);
  }

  // Header state and scroll-to-top button.
  $(window).on("scroll", function () {
    if ($(this).scrollTop() > 360) {
      $("#scrollTopBtn").fadeIn(180).css("display", "grid");
    } else {
      $("#scrollTopBtn").fadeOut(180);
    }
  });

  $("#scrollTopBtn").on("click", function () {
    $("html, body").animate({ scrollTop: 0 }, 650);
  });

  // Reusable form validation helpers.
  function isEmail(email) {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
  }

  function setError($field, message) {
    $field.addClass("is-invalid");
    $field.closest("div").find(".error-text").first().text(message);
  }

  function clearError($field) {
    $field.removeClass("is-invalid");
    $field.closest("div").find(".error-text").first().text("");
  }

  function validateRequired($field, message) {
    const value = $.trim($field.val());
    if (!value) {
      setError($field, message);
      return false;
    }
    clearError($field);
    return true;
  }

  function validateEmailField($field) {
    const value = $.trim($field.val());
    if (!value) {
      setError($field, "Email is required.");
      return false;
    }
    if (!isEmail(value)) {
      setError($field, "Enter a valid email address.");
      return false;
    }
    clearError($field);
    return true;
  }

  function validatePhone($field) {
    const value = $.trim($field.val());
    if (!value) {
      setError($field, "Phone number is required.");
      return false;
    }
    if (!/^[0-9+\-\s()]{7,18}$/.test(value)) {
      setError($field, "Enter a valid phone number.");
      return false;
    }
    clearError($field);
    return true;
  }

  // Feedback form validation.
  $("#feedbackForm").on("submit", function (event) {
    event.preventDefault();

    let valid = true;
    valid = validateRequired($("#fullName"), "Full name is required.") && valid;
    valid = validateEmailField($("#feedbackEmail")) && valid;
    valid = validatePhone($("#phone")) && valid;
    valid = validateRequired($("#feedbackMessage"), "Feedback message is required.") && valid;

    if (!$('input[name="rating"]:checked').length) {
      $(".rating-error").text("Please select a rating.");
      valid = false;
    } else {
      $(".rating-error").text("");
    }

    if (valid) {
      $("#feedbackSuccess").stop(true, true).fadeIn(220);
      this.reset();
      setTimeout(() => $("#feedbackSuccess").fadeOut(220), 3600);
    }
  });

  // Query form validation.
  $("#queryForm").on("submit", function (event) {
    event.preventDefault();

    let valid = true;
    valid = validateRequired($("#queryName"), "Name is required.") && valid;
    valid = validateEmailField($("#queryEmail")) && valid;
    valid = validateRequired($("#subject"), "Subject is required.") && valid;
    valid = validateRequired($("#queryMessage"), "Message is required.") && valid;

    if (valid) {
      $("#querySuccess").stop(true, true).fadeIn(220);
      this.reset();
      setTimeout(() => $("#querySuccess").fadeOut(220), 3600);
    }
  });

  // Live cleanup after users fix fields.
  $(document).on("input", ".form-control", function () {
    clearError($(this));
  });

  $(document).on("change", 'input[name="rating"]', function () {
    $(".rating-error").text("");
  });
});
